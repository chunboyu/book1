<div id="pagination" class="clearfix">
	<?php pagination(); ?>
</div>
<p class="hidden"><?php posts_nav_link(); ?></p>